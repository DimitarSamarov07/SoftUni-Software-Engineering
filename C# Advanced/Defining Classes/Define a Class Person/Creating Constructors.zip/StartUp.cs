﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person johny = new Person("Ivan",12);
            Console.WriteLine(johny.Name+" "+johny.Age);
            
        }
    }
}
