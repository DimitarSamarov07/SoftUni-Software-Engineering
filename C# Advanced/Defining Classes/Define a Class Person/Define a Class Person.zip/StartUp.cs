﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
            Person people=new Person();
            people.Name = "Ivan";
            people.Age = 2;
            Console.WriteLine(people.Name+" "+people.Age);
        }
    }
}
