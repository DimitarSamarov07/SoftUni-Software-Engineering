﻿namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS;Database=FootballBetting;Integrated Security=true";
    }
}
