﻿namespace MusicHub.DataProcessor.ImportDtos
{
    using System;

    public class ImportAlbumDto
    {
        public string Name { get; set; }

        public string ReleaseDate { get; set; }
    }
}
