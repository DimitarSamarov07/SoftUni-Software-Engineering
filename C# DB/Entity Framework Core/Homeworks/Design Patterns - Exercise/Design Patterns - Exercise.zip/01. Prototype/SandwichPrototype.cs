﻿namespace _01._Prototype
{
    public abstract class SandwichPrototype
    {
        public abstract SandwichPrototype Clone();
    }
}
