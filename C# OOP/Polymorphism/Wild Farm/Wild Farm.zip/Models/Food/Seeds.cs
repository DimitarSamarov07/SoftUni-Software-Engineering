﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Core.Food
{
    public class Seeds:Food
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}
